package prachi.com.thsensorusingasynctask;

import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Random;

public class MainActivity extends AppCompatActivity {

    EditText mEnterNumber;
    Button mGenrate;
    ListView mListView;
    Button mCancelButton;
    String num;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        mEnterNumber = (EditText)findViewById(R.id.enterNumber);
        mGenrate = (Button)findViewById(R.id.genrateButton);
        mListView = (ListView)findViewById(R.id.listView);
        mCancelButton = (Button)findViewById(R.id.cancelButton);

        mListView.setAdapter(new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,new ArrayList<String>()));

        mGenrate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                THSensor obj = new THSensor();
                num = mEnterNumber.getText().toString();
                obj.execute(num);
            }
        });

        mCancelButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });
    }


    public class THSensor extends AsyncTask<String,String,String>{
        ArrayAdapter<String> adapter;
        private String resp;
        ProgressBar mProgressBar;
        int count;

        @Override
        protected void onPreExecute() {


            adapter = (ArrayAdapter<String>)mListView.getAdapter();
            mProgressBar = (ProgressBar)findViewById(R.id.progressBar);
            mProgressBar.setMax(Integer.parseInt(num));
            mProgressBar.setProgress(0);
            mProgressBar.setVisibility(View.VISIBLE);
            count = 0;
        }


        @Override
        protected String doInBackground(String... params) {

            int num = Integer.parseInt(String.valueOf(params[0]));

            for(int p = 1;p<=num;p++){

                Random randomGenrator = new Random();
                int temp = randomGenrator.nextInt(120);
                int humid = randomGenrator.nextInt(100);
                int activity = randomGenrator.nextInt(500);

                resp = "Output " + p +":" + "\n" + "Temperature:" + temp + "F" + "\n" + "Humidity:" + humid +"%" + "\n" + "Activity:" + activity;

                publishProgress(resp);

                try {
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }

            }
            return "All Values are Written";
        }

        @Override
        protected void onProgressUpdate(String... values) {
            adapter.add(values[0]);
            count++;
            mProgressBar.setProgress(count);
        }

        @Override
        protected void onPostExecute(String result) {
            Toast.makeText(getApplicationContext(),result,Toast.LENGTH_LONG).show();
            mProgressBar.setVisibility(View.GONE);
        }
    }

}
